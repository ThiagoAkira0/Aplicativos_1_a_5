package com.example.questao5;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResumoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resumo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textResumo = findViewById(R.id.txtResumo);
        Button btnNovo = findViewById(R.id.btnNovo);

        // Receber os dados
        Intent intent = getIntent();
        String sabores = intent.getStringExtra("sabores");
        String tamanho = intent.getStringExtra("tamanho");
        String pagamento = intent.getStringExtra("pagamento");
        double valor = intent.getDoubleExtra("valor", 0);

        @SuppressLint("DefaultLocale") String resumo = "Resumo do Pedido:\n\n" +
                "Sabores: " + sabores + "\n" +
                "Tamanho e valor Total: " + tamanho + "\n" +
                "Pagamento: " + pagamento + "\n" ;

        textResumo.setText(resumo);

        btnNovo.setOnClickListener(view -> {
            Intent voltar = new Intent(this, MainActivity.class);
            voltar.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // limpa a pilha
            startActivity(voltar);
        });
    }
}