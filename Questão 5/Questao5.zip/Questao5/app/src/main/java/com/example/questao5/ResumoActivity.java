package com.example.questao5;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResumoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resumo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        TextView txtResumo = findViewById(R.id.txtResumo);

        //Pegando os valores do PaymentActivity

        String sabores = getIntent().getStringExtra("sabores");
        String tamanho = getIntent().getStringExtra("tamanho");
        String pagamento = getIntent().getStringExtra("pagamento");
        int total = getIntent().getIntExtra("total", 0);

        //Resumo do pedido
        String resumo = "Sabores:\n" + sabores + "\nTamanho: " + tamanho + "\nPagamento: " + pagamento + "\nTotal: R$" + total;
        txtResumo.setText(resumo);


        //Clique para voltar para tela inicial
        Button botao = findViewById(R.id.btnNovo);
        botao.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ResumoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}