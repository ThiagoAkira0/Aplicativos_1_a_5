package com.example.questao5;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Criando e puxando variáveis
        CheckBox checkPortuguesa = findViewById(R.id.checkPortuguesa);
        CheckBox checkFrango = findViewById(R.id.checkFrango);
        CheckBox checkCalabresa = findViewById(R.id.checkCalabresa);
        CheckBox checkMussarela = findViewById(R.id.checkMussarela);
        CheckBox checkMarguerita = findViewById(R.id.checkMarguerita);
        CheckBox checkEscarola = findViewById(R.id.checkEscarola);
        Button btnAvancar = findViewById(R.id.btnAvancar);


        btnAvancar.setOnClickListener(v -> {
            StringBuilder saboresSelecionados = new StringBuilder();
            if (checkPortuguesa.isChecked()) saboresSelecionados.append("Portuguesa");
            if (checkFrango.isChecked()) saboresSelecionados.append("Frango com Catupiry");
            if (checkCalabresa.isChecked()) saboresSelecionados.append("Calabresa ");
            if (checkMussarela.isChecked()) saboresSelecionados.append("Mussarela");
            if (checkMarguerita.isChecked()) saboresSelecionados.append("Marguerita ");
            if (checkEscarola.isChecked()) saboresSelecionados.append("Escarola");

            Intent intent = new Intent(MainActivity.this, PaymentActivity.class);
            intent.putExtra("saboresSelecionados", saboresSelecionados.toString().trim());
            startActivity(intent);
        });
    }
}