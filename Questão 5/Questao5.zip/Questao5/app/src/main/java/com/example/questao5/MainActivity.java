package com.example.questao5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });


        //Criando e puxando variáveis
        CheckBox checkPortuguesa = findViewById(R.id.checkPortuguesa);
        CheckBox checkFrango = findViewById(R.id.checkFrango);
        CheckBox checkCalabresa = findViewById(R.id.checkCalabresa);
        CheckBox checkMussarela = findViewById(R.id.checkMussarela);
        CheckBox checkMarguerita = findViewById(R.id.checkMarguerita);
        CheckBox checkEscarola = findViewById(R.id.checkEscarola);
        Button btnAvancar = findViewById(R.id.btnAvancar);

        String sabores = "";

        //Função OnClick para ir para a Segunda Tela, enquanto soma a
        //quantidade de pizzas escolhidas de acordo com a quantidade de sabores escolhida
        btnAvancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sabores = "";
                int quantidadeSabores = 0;

                if (checkPortuguesa.isChecked()) {
                    sabores += "Portuguesa\n";
                    quantidadeSabores++;
                }
                if (checkFrango.isChecked()) {
                    sabores += "Frango com Catupiry\n";
                    quantidadeSabores++;
                }
                if (checkCalabresa.isChecked()) {
                    sabores += "Calabresa\n";
                    quantidadeSabores++;
                }
                if (checkMussarela.isChecked()) {
                    sabores += "Mussarela\n";
                    quantidadeSabores++;
                }
                if (checkMarguerita.isChecked()) {
                    sabores += "Marguerita\n";
                    quantidadeSabores++;
                }
                if (checkEscarola.isChecked()) {
                    sabores += "Escarola\n";
                    quantidadeSabores++;
                }

                if (quantidadeSabores == 0) {
                    Toast.makeText(MainActivity.this, "Selecione pelo menos um sabor!", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Mandando os sabores e quantas pizzas escolhidas
                Intent intent = new Intent(MainActivity.this, PaymentActivity.class);
                intent.putExtra("sabores", sabores);
                intent.putExtra("quantidade", quantidadeSabores);
                startActivity(intent);
            }
        });
    }
}