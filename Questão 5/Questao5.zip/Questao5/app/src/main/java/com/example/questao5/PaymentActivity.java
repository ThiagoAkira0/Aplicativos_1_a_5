package com.example.questao5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_payment);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        RadioGroup radioTamanho = findViewById(R.id.radioTamanho);
        RadioGroup radioPagamento = findViewById(R.id.radioPagamento);
        Button btnFinalizar = findViewById(R.id.btnFinalizar);

        //Pegando os sabores do MainActivity
        Intent intent = getIntent();
        String sabores = intent.getStringExtra("sabores");
        int quantidade = intent.getIntExtra("quantidade", 0);

        //Função OnClick para ir para ResumoActivity, enviando qual o tamanho e o pagamento
        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int valorUnitario = 0;
                String tamanho = "";
                String pagamento = "";

                int tamanhoSelecionado = radioTamanho.getCheckedRadioButtonId();
                int pagamentoSelecionado = radioPagamento.getCheckedRadioButtonId();

                if (tamanhoSelecionado == R.id.radioPequena) {
                    valorUnitario = 50;
                    tamanho = "Pequena";
                } else if (tamanhoSelecionado == R.id.radioMedia) {
                    valorUnitario = 60;
                    tamanho = "Média";
                } else if (tamanhoSelecionado == R.id.radioGrande) {
                    valorUnitario = 70;
                    tamanho = "Grande";
                }


                if (pagamentoSelecionado == R.id.radioPix) {
                    pagamento = "PIX";
                } else if (pagamentoSelecionado == R.id.radioCartaoC) {
                    pagamento = "Cartão de Crédito";
                } else if (pagamentoSelecionado == R.id.radioCartaoD) {
                pagamento = "Cartão de Débito";
                }

                int valorTotal = valorUnitario * quantidade;
                Intent resumo = new Intent(PaymentActivity.this, ResumoActivity.class);
                resumo.putExtra("sabores", sabores);
                resumo.putExtra("tamanho", tamanho);
                resumo.putExtra("pagamento", pagamento);
                resumo.putExtra("total", valorTotal);
                startActivity(resumo);
            }
        });
    }
}
