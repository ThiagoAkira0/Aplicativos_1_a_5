package com.example.questao5;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_payment);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Pegando variáveis e criando
        RadioGroup grupoPagamento = findViewById(R.id.grupoPagamento);
        RadioGroup grupoTamanho = findViewById(R.id.grupoTamanho);
        Button btnFinalizar = findViewById(R.id.btnFinalizar);

        btnFinalizar.setOnClickListener(view -> {
            int tamanhoId = grupoTamanho.getCheckedRadioButtonId();
            int pagamentoId = grupoPagamento.getCheckedRadioButtonId();

            //Condição caso os campos de tamanho ou pagamento estejam vazios
            if (tamanhoId == -1 || pagamentoId == -1) {
                Toast.makeText(this, "Selecione tamanho e pagamento!", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton tamanhoSelecionado = findViewById(tamanhoId);
            RadioButton pagamentoSelecionado = findViewById(pagamentoId);

            String tamanho = tamanhoSelecionado.getText().toString();
            String pagamento = pagamentoSelecionado.getText().toString();

            // Valor baseado apenas no tamanho
            double valor = 0;
            if (tamanho.equalsIgnoreCase("@string/Pequeno")) {
                valor = 50.0;
            } else if (tamanho.equalsIgnoreCase("Média")) {
                valor = 60.0;
            } else if (tamanho.equalsIgnoreCase("Grande")) {
                valor = 70.0;
            }

            // Recuperar sabores da primeira tela
            String sabores = getIntent().getStringExtra("saboresSelecionados");

            // Enviar para a tela de resumo
            Intent intent = new Intent(this, ResumoActivity.class);
            intent.putExtra("sabores", sabores);
            intent.putExtra("tamanho", tamanho);
            intent.putExtra("pagamento", pagamento);
            intent.putExtra("valor", valor);
            startActivity(intent);
        });

    }
}