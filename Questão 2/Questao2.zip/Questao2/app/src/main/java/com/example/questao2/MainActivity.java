package com.example.questao2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText editSalario;
    RadioGroup radioGroup;
    Button btnResultado;
    TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Puxando os dados
        editSalario = findViewById(R.id.editTextSalario);
        radioGroup = findViewById(R.id.radioGroup);
        btnResultado = findViewById(R.id.btnResultado);
        textResultado = findViewById(R.id.textResultado);

        //Botao para calcular salário novo
        btnResultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //"Informar o salario" caso o campo esteja vazio
                String salarioStr = editSalario.getText().toString();
                if (salarioStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Informe o salário", Toast.LENGTH_SHORT).show();
                    return;
                }
                double salario = Double.parseDouble(salarioStr);
                int selectedId = radioGroup.getCheckedRadioButtonId();

                //"Selecione um percentil" caso o campo de porcentagens esteja vazio
                if (selectedId == -1) {
                    Toast.makeText(MainActivity.this, "Selecione um percentual", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Cálculo para as porcentagens
                double percentual = 0;
                if (selectedId == R.id.radio40) percentual = 0.40;
                else if (selectedId == R.id.radio45) percentual = 0.45;
                else if (selectedId == R.id.radio50) percentual = 0.50;

                double novoSalario = salario + (salario * percentual);
                textResultado.setText(String.format("NOVO SALÁRIO: R$ %.2f", novoSalario));
            }
        });
    }
}