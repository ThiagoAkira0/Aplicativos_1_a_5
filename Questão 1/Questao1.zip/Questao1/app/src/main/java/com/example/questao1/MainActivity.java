package com.example.questao1;

import static java.lang.String.*;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    //Declarando atributos
    CheckBox checkArroz, checkLeite, checkCarne, checkFeijao, checkRefri;
    TextView txtTotal;
    Button btnTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Chamando os itens
        checkArroz = findViewById(R.id.checkBArroz);
        checkLeite = findViewById(R.id.checkBLeite);
        checkCarne = findViewById(R.id.checkBCarne);
        checkFeijao = findViewById(R.id.checkBFeijao);
        checkRefri = findViewById(R.id.checkBCoca);
        txtTotal = findViewById(R.id.txtTotal);
        btnTotal = findViewById(R.id.btnResultado);


        //Botão para calcular o resultado da compra
        btnTotal.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("DefaultLocale")
            public void onClick(View v) {
                double total = 0.0;

                if (checkArroz.isChecked()) total += 2.69;
                if (checkLeite.isChecked()) total += 2.70;
                if (checkCarne.isChecked()) total += 16.70;
                if (checkFeijao.isChecked()) total += 3.38;
                if (checkRefri.isChecked()) total += 3.00;

                txtTotal.setText(format("Total: R$ %.2f", total));
            }
        });
    }
}