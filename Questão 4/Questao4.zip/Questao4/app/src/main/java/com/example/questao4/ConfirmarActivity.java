package com.example.questao4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ConfirmarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_confirmar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        TextView textPedido = findViewById(R.id.txtPedidoC);
        //Chama o nome e o pedido do cliente
        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String lanche = intent.getStringExtra("lanche");

        textPedido.setText("Olá " + nome + ", seu pedido de: " + "\n" + lanche + " foi registrado!");

        //Clique para ir para o MainActivity
        Button botao = findViewById(R.id.btnVoltar);
        botao.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ConfirmarActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}