package com.example.questao4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PedidoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pedido);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Chamando as variáveis
        EditText editNome = findViewById(R.id.editNome);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        Button btnConfirmar = findViewById(R.id.btnConfirmar);

        //Clique para ir para a tela de confirmação de pedido
        //Se o nome ou o radioGroup estiver vazio: "Preencha todos os campos"
        btnConfirmar.setOnClickListener(v -> {
            String nome = editNome.getText().toString().trim();
            int selecionado = radioGroup.getCheckedRadioButtonId();
            if (nome.isEmpty() || selecionado == -1) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton lancheSelecionado = findViewById(selecionado);
            String lanche = lancheSelecionado.getText().toString();

            Intent intent = new Intent(this, ConfirmarActivity.class);

            //Para passar os dados
            intent.putExtra("nome", nome);
            intent.putExtra("lanche", lanche);
            startActivity(intent);
        });
    }
}